/*
 * Create 2021/07/06
 * Author koutakimura
 * Editor VSCode ver1.57.1
 * -
 * アイテムと装備に関するデータベースを管理するヘッダーファイル
 */

#ifndef item_db_h   /* prevent circular inclusions */
#define item_db_h   /* by using protection macros */


/*
 * アイテムメッセージ取得
 */
#define NUM(ary) (sizeof(ary)/sizeof(ary[0]))
#include "item_msg.h"


/*
 * 構造体の要素数
 */
#define ITEM_DB_SIZE	  ((sizeof (item_db))   / (sizeof (ItemDB)))
#define WEAPON_DB_SIZE	  ((sizeof (weapon_db)) / (sizeof (WeaponDB)))
#define ARMOR_DB_SIZE	  ((sizeof (armor_db))  / (sizeof (ArmorDB)))
#define AMULET_DB_SIZE	  ((sizeof (amulet_db)) / (sizeof (AmuletDB)))


/* TODO
 * アイテム・装備データベースをSDカードから読み込むように変更する
 * item.bin
 * equip.bin
 * amulet.bin
 * という風に分けて、一度に全データを読み込みを行い
 * binファイルを読み込んだ開始アドレスを構造体に保存しておく。
 * 
 * 例
 * item.bin 
 * 開始アドレス 0x0060_0000
 * 文字列を含めて1000回読み込んだ 
 * 0x0060_0000 + 1000 x 4byte = 0x0060_4000  適当な構造体[0] = 1000
 * 
 * equip.binの書き込みアドレスは0x0060_4000から始める ---
 */


/*
 * ver1. 2021/07/10
 * バトルに使用するアイテムに関するデータベース
 * 
 * id           アイテムID
 * cool_type    アイテム使用後のクールタイムID
 * use_type     アイテムの使用効果
 * msg          アイテムの説明
 * name         アイテム名
 */
typedef struct item_db
{
    uint32_t id;
    uint8_t cool_type;
    uint8_t use_type;
    const char *name;
    const char *msg;
} ItemDB;

static const ItemDB item_db[] =
{
    {ITEM_DANGO,           COOL_TIME_1,     ITEM_TYPE_HEEL_1,         "甘味処の団子",               ITEM_MSG0,},
    {ITEM_SASADANGO,       COOL_TIME_2,     ITEM_TYPE_HEEL_2,         "甘味処の笹団子",             ITEM_MSG1,},
    {ITEM_OUGONDANGO,      COOL_TIME_3,     ITEM_TYPE_HEEL_3,         "甘味処の黄金団子",           ITEM_MSG2,},
    {ITEM_GENSOUDANGO,     COOL_TIME_4,     ITEM_TYPE_HEEL_4,         "甘味処の幻想団子",           ITEM_MSG3,},
    {ITEM_ARISU_COOKEI_1,  COOL_TIME_2,     ITEM_TYPE_HEEL_ALL_1,     "アリスの黒炭クッキー",       ITEM_MSG4,},
    {ITEM_ARISU_COOKEI_2,  COOL_TIME_4,     ITEM_TYPE_HEEL_ALL_2,     "アリスの義理クッキー",       ITEM_MSG5,},
    {ITEM_ARISU_COOKEI_3,  COOL_TIME_6,     ITEM_TYPE_HEEL_ALL_3,     "アリスの本命クッキー",       ITEM_MSG6,},
    {ITEM_MARISA_KINOKO,   COOL_TIME_2,     ITEM_TYPE_RECOVER,        "魔法の森産テングダケ",       ITEM_MSG7,},
    {ITEM_YAGOKORODORINKU, COOL_TIME_7,     ITEM_TYPE_REVIVE,         "八意ドリンク",               ITEM_MSG8,},
    {ITEM_HOURAIDORINK,    COOL_TIME_10,    ITEM_TYPE_REVIVE_ALL,     "蓬莱ドリンク",               ITEM_MSG9,},
    {ITEM_HAKUREI_DOBU,    COOL_TIME_3,     ITEM_TYPE_SP_1,          "博麗印のどぶ水",              ITEM_MSG10,},
    {ITEM_HAKUREI_IDO,     COOL_TIME_5,     ITEM_TYPE_SP_2,          "博麗印の井戸水",              ITEM_MSG11,},
    {ITEM_HAKUREI_WATER,   COOL_TIME_7,     ITEM_TYPE_SP_3,          "博麗印の天然水",              ITEM_MSG12,},
    {ITEM_HAKUREI_GOD,     COOL_TIME_8,     ITEM_TYPE_SP_4,          "博麗印のお神酒",              ITEM_MSG13,},
    {ITEM_KAPPA_SIELD,     COOL_TIME_2,     ITEM_TYPE_ATTACK_SIELD,  "光学迷彩・物",                ITEM_MSG14,},
    {ITEM_KAPPA_MAGIC,     COOL_TIME_2,     ITEM_TYPE_MAGIC_SIELD,   "光学迷彩・魔",                ITEM_MSG15,},
    {ITEM_SANAE_OMAMORI,   COOL_TIME_9,     ITEM_TYPE_AMULET,        "早苗のお守り",                ITEM_MSG16,},
    {ITEM_SEIZYA_ESCAPE,   COOL_TIME_1,     ITEM_TYPE_ESCAPE,        "お尋ね者はご用心",            ITEM_MSG17,},
    {ITEM_ONI_POWER,       COOL_TIME_5,     ITEM_TYPE_POWER,         "鬼神の怪力薬",                ITEM_MSG18,},
    {ITEM_ONI_SYURAN,      COOL_TIME_1,     ITEM_TYPE_BERSERKER,     "伊吹瓢",                      ITEM_MSG19,},
};


/*
 * ver1. 2021/07/10
 * 武器情報を管理するデータベース
 * 
 * id           武器ID
 * atk          攻撃力
 * effect       武器の効果、4byteのbitで定義
 * equip_hero   装備可能な仲間、1byteのbitで管理
 * buy          店買値  0の時は店購入ではない
 * cell         店売値  0の時は売ることはできない
 * name         武器名
 */
typedef struct weapon_db
{
    uint8_t  id;
    uint8_t  atk;
    uint32_t effect_type;
    uint8_t  equip_hero;
    uint32_t buy;
    uint32_t cell;
    const char *name;
    const char *msg;
} WeaponDB;

static const WeaponDB weapon_db[] =
{
    {WEAPON_SWORAD_TETU,          12,   WEAPON_SWORAD_TETU_TYPE,                EQUIP_HERO_SWORD,      10,      3,       "鉄の剣",                       WEAPON_MSG0},
    {WEAPON_SWORAD_BEND,          15,   WEAPON_SWORAD_BEND_TYPE,                EQUIP_HERO_SWORD,      15,      5,       "曲剣",                         WEAPON_MSG1},
    {WEAPON_SWORAD_RONG,          20,   WEAPON_SWORAD_RONG_TYPE,                EQUIP_HERO_SWORD,      20,      6,       "ロングソード",                 WEAPON_MSG2},
    {WEAPON_SWORAD_SILBER,        25,   WEAPON_SWORAD_SILBER_TYPE,              EQUIP_HERO_SWORD,      30,     10,       "シルバーソード",               WEAPON_MSG3},
    {WEAPON_SWORAD_HONOO,         35,   WEAPON_SWORAD_HONOO_TYPE,               EQUIP_HERO_SWORD,      60,     20,       "炎の剣",                       WEAPON_MSG4},
    {WEAPON_SWORAD_HISOUKEN,      50,   WEAPON_SWORAD_HISOUKEN_TYPE,            I_TENK,                 0,      0,       "緋想の剣",                     WEAPON_MSG5},
    {WEAPON_SWORAD_GOURYUU,       60,   WEAPON_SWORAD_GOURYUU_TYPE,             EQUIP_HERO_SWORD,       0,     70,       "剛竜剣",                       WEAPON_MSG6},
    {WEAPON_SWORAD_MANAMUNE,      70,   WEAPON_SWORAD_MANAMUNE_TYPE,            EQUIP_HERO_SWORD,     200,     60,       "マサムネ",                     WEAPON_MSG7},
    {WEAPON_SWORAD_MURAMASA,      70,   WEAPON_SWORAD_MURAMASA_TYPE,            EQUIP_HERO_SWORD,     200,     60,       "ムラマサ",                     WEAPON_MSG8},
    {WEAPON_SWORAD_ZANTETRU,       5,   WEAPON_SWORAD_ZANTETRU_TYPE,            I_KOGA,                 0,      0,       "神魔おどろけまる",          WEAPON_MSG9},
    {WEAPON_SWORAD_SIN_HISOUKEN,  10,   WEAPON_SWORAD_SIN_HISOUKEN_TYPE,        I_TENK,                 0,      0,       "真・緋想の剣",                 WEAPON_MSG10},
    {WEAPON_SHORT_SHORT,           6,   WEAPON_SHORT_SHORT_TYPE,                EQUIP_HERO_SHORT,       8,      2,       "ナイフ",                       WEAPON_MSG11},
    {WEAPON_SHORT_BATER,           9,   WEAPON_SHORT_BATER_TYPE,                EQUIP_HERO_SHORT,      13,      4,       "バターナイフ",                 WEAPON_MSG12},
    {WEAPON_SHORT_POIZUN,         13,   WEAPON_SHORT_POIZUN_TYPE,               EQUIP_HERO_SHORT,       0,     15,       "ポイズンダガー",               WEAPON_MSG13},
    {WEAPON_SHORT_ASSASSIN,       16,   WEAPON_SHORT_ASSASSIN_TYPE,             EQUIP_HERO_SHORT,      30,      6,       "アサシンダガー",               WEAPON_MSG14},
    {WEAPON_SHORT_KILLER,         20,   WEAPON_SHORT_KILLER_TYPE,               EQUIP_HERO_SHORT,       0,     20,       "キラーナイフ",                 WEAPON_MSG15},
    {WEAPON_SHORT_ICE,            23,   WEAPON_SHORT_ICE_TYPE,                  EQUIP_HERO_SHORT,      30,      6,       "アイスナイフ",                 WEAPON_MSG16},
    {WEAPON_SHORT_SARAMANDER,     26,   WEAPON_SHORT_SARAMANDER_TYPE,           EQUIP_HERO_SHORT,      60,     20,       "サラマンダー",                 WEAPON_MSG17},
    {WEAPON_SWORAD_DRAGON,        38,   WEAPON_SWORAD_DRAGON_TYPE,              EQUIP_HERO_SHORT,     220,     70,       "ドラゴンキラー",               WEAPON_MSG18},
    {WEAPON_SHORT_HURAGA,         50,   WEAPON_SHORT_HURAGA_TYPE,               EQUIP_HERO_SHORT,       0,     60,       "フラガラッハ",                 WEAPON_MSG19},
    {WEAPON_SHORT_KURONOS,        60,   WEAPON_SHORT_KURONOS_TYPE,              EQUIP_HERO_SHORT,       0,    250,       "クロノスエッジ",               WEAPON_MSG20},
    {WEAPON_SWORAD_ALTEMA,        70,   WEAPON_SWORAD_ALTEMA_TYPE,              I_SIZU,                 0,      0,       "神刀紅葉おろし",               WEAPON_MSG21},
    {WEAPON_SPEAR_NIGHT,          14,   WEAPON_SPEAR_NIGHT_TYPE,                EQUIP_HERO_SPEAR,      20,      6,       "ナイトスピア",                 WEAPON_MSG22},
    {WEAPON_SPEAR_SILBER,         25,   WEAPON_SPEAR_SILBER_TYPE,               EQUIP_HERO_SPEAR,      30,     10,       "シルバースピア",               WEAPON_MSG23},
    {WEAPON_SPEAR_TRIDENT,        32,   WEAPON_SPEAR_TRIDENT_TYPE,              EQUIP_HERO_SPEAR,       0,     20,       "トライデント",                 WEAPON_MSG24},
    {WEAPON_SPEAR_RAIZIN,         36,   WEAPON_SPEAR_RAIZIN_TYPE,               EQUIP_HERO_SPEAR,       0,     20,       "雷神槍",                       WEAPON_MSG25},
    {WEAPON_SPEAR_HONOO,          42,   WEAPON_SPEAR_HONOO_TYPE,                EQUIP_HERO_SPEAR,      70,     20,       "炎の槍",                       WEAPON_MSG26},
    {WEAPON_SPEAR_DEAMON,         52,   WEAPON_SPEAR_DEAMON_TYPE,               EQUIP_HERO_SPEAR,       0,     40,       "デーモンスピア",               WEAPON_MSG27},
    {WEAPON_SPEAR_KING,           62,   WEAPON_SPEAR_KING_TYPE,                 EQUIP_HERO_SPEAR,       0,     50,       "海龍王の槍",                   WEAPON_MSG28},
    {WEAPON_SPEAR_TRISHULA,       74,   WEAPON_SPEAR_TRISHULA_TYPE,             EQUIP_HERO_SPEAR,     250,     70,       "トリシューラ",                 WEAPON_MSG29},
    {WEAPON_SPEAR_LONGINUS,       95,   WEAPON_SPEAR_LONGINUS_TYPE,             EQUIP_HERO_SPEAR,       0,    100,       "ロンギヌス",                   WEAPON_MSG30},
    {WEAPON_SPEAR_GAEBOLGA,       15,   WEAPON_SPEAR_GAEBOLGA_TYPE,             EQUIP_HERO_SPEAR,       0,    220,       "ゲイボルグ",                   WEAPON_MSG31},
    {WEAPON_SPEAR_THE_GUNGNIR,    30,   WEAPON_SPEAR_THE_GUNGNIR_TYPE,          I_REMY,                 0,      0,       "レミ嬢・ざ・ぐんぐにる",        WEAPON_MSG32},
    {WEAPON_KODUTI,               10,   WEAPON_KODUTI_TYPE,                     EQUIP_HERO_HAMMER,     12,      4,       "こづち",                       WEAPON_MSG33},
    {WEAPON_KODUTI_MORI,          17,   WEAPON_KODUTI_MORI_TYPE,                EQUIP_HERO_HAMMER,      0,      8,       "森のハンマー",                 WEAPON_MSG34},
    {WEAPON_KODUTI_DAITI,         23,   WEAPON_KODUTI_DAITI_TYPE,               EQUIP_HERO_HAMMER,     25,     10,       "大地のハンマー",               WEAPON_MSG35},
    {WEAPON_KODUTI_HUGOU,         30,   WEAPON_KODUTI_HUGOU_TYPE,               EQUIP_HERO_HAMMER,      0,     50,       "こがねもち",                   WEAPON_MSG36},
    {WEAPON_KODUTI_KOORI,         33,   WEAPON_KODUTI_KOORI_TYPE,               EQUIP_HERO_HAMMER,     30,     10,       "アイスハンマー",               WEAPON_MSG37},
    {WEAPON_KODUTI_HONOO,         38,   WEAPON_KODUTI_HONOO_TYPE,               EQUIP_HERO_HAMMER,     70,     20,       "ファイアーハンマー",           WEAPON_MSG38},
    {WEAPON_KODUTI_KAMIGOROSI,    44,   WEAPON_KODUTI_KAMIGOROSI_TYPE,          EQUIP_HERO_HAMMER,      0,      1,       "かみごろし",                   WEAPON_MSG39},
    {WEAPON_KODUTI_TORL,          54,   WEAPON_KODUTI_TORL_TYPE,                EQUIP_HERO_HAMMER,      0,     35,       "トールハンマー",               WEAPON_MSG40},
    {WEAPON_KODUTI_TOUMOKOROSI,   62,   WEAPON_KODUTI_TOUMOKOROSI_TYPE,         I_MINO,                 0,      5,       "とうもごろし",                 WEAPON_MSG41},
    {WEAPON_KODUTI_DANZAI,        72,   WEAPON_KODUTI_DANZAI_TYPE,              EQUIP_HERO_HAMMER,    230,     70,       "断罪の鉄槌",                   WEAPON_MSG42},
    {WEAPON_KODUTI_GIANT,         90,   WEAPON_KODUTI_GIANT_TYPE,               EQUIP_HERO_HAMMER,      0,    100,       "ギガントハンマー",             WEAPON_MSG43},
    {WEAPON_KODUTI_UTIDENO,       15,   WEAPON_KODUTI_UTIDENO_TYPE,             I_MINO,                 0,      0,       "豊穣神のこづち",               WEAPON_MSG44},
    {WEAPON_KODUTI_ONBASIRA,      25,   WEAPON_KODUTI_ONBASIRA_TYPE,            I_KANA,                 0,      0,       "ゴッドオブオンバシラ",         WEAPON_MSG45},
    {WEAPON_UMBRELLA_SUN,          8,   WEAPON_UMBRELLA_SUN_TYPE,               EQUIP_HERO_UMBRELLA,   15,      5,       "日傘",                         WEAPON_MSG46},
    {WEAPON_UMBRELLA_PARASOL,     12,   WEAPON_UMBRELLA_PARASOL_TYPE,           EQUIP_HERO_UMBRELLA,   20,      6,       "パラソル",                     WEAPON_MSG47},
    {WEAPON_UMBRELLA_AIAI,        14,   WEAPON_UMBRELLA_AIAI_TYPE,              EQUIP_HERO_UMBRELLA,    0,      8,       "あいあい傘",                   WEAPON_MSG48},
    {WEAPON_UMBRELLA_KURENAI,     20,   WEAPON_UMBRELLA_KURENAI_TYPE,           EQUIP_HERO_UMBRELLA,   40,     15,       "紅色傘",                       WEAPON_MSG49},
    {WEAPON_UMBRELLA_KOUMORI,     25,   WEAPON_UMBRELLA_KOUMORI_TYPE,           EQUIP_HERO_UMBRELLA,    0,     10,       "こうもり傘",                   WEAPON_MSG50},
    {WEAPON_UMBRELLA_HISUI,       30,   WEAPON_UMBRELLA_HISUI_TYPE,             EQUIP_HERO_UMBRELLA,    0,     50,       "ヒスイのアンブレラ",           WEAPON_MSG51},
    {WEAPON_UMBRELLA_PLATINUM,    40,   WEAPON_UMBRELLA_PLATINUM_TYPE,          EQUIP_HERO_UMBRELLA,  220,    100,       "プラチナの傘",                 WEAPON_MSG52},
    {WEAPON_UMBRELLA_ROVE,        45,   WEAPON_UMBRELLA_ROVE_TYPE,              EQUIP_HERO_UMBRELLA,    0,     30,       "ラブリーパラソル",             WEAPON_MSG53},
    {WEAPON_UMBRELLA_BLOOD,       55,   WEAPON_UMBRELLA_BLOOD_TYPE,             EQUIP_HERO_UMBRELLA,    0,    100,       "ブラッディクロス",             WEAPON_MSG54},
    {WEAPON_UMBRELLA_ORIHARUKON,  75,   WEAPON_UMBRELLA_ORIHARUKON_TYPE,        EQUIP_HERO_UMBRELLA,    0,    150,       "オリハルコンの傘",             WEAPON_MSG55},
    {WEAPON_UMBRELLA_KOGASA,      10,   WEAPON_UMBRELLA_KOGASA_TYPE,            I_YUKA,                 0,      0,       "小傘",                         WEAPON_MSG56},
    {WEAPON_ROD,                   4,   WEAPON_ROD_TYPE,                        EQUIP_HERO_ROD,        10,      3,       "ただの杖",                     WEAPON_MSG57},
    {WEAPON_ROD_TREE,              7,   WEAPON_ROD_TREE_TYPE,                   EQUIP_HERO_ROD,        20,      6,       "森の杖",                       WEAPON_MSG58},
    {WEAPON_ROD_MAGIC,            10,   WEAPON_ROD_MAGIC_TYPE,                  EQUIP_HERO_ROD,         0,     10,       "魔力の杖",                     WEAPON_MSG59},
    {WEAPON_ROD_KYANDY,           13,   WEAPON_ROD_KYANDY_TYPE,                 EQUIP_HERO_ROD,         0,     30,       "キャンディロッド",             WEAPON_MSG60},
    {WEAPON_ROD_HONOO,            15,   WEAPON_ROD_HONOO_TYPE,                  EQUIP_HERO_ROD,        70,     20,       "炎の杖",                       WEAPON_MSG61},
    {WEAPON_ROD_BLOOD,            17,   WEAPON_ROD_BLOOD_TYPE,                  EQUIP_HERO_ROD,         0,      5,       "ブラッディロッド",             WEAPON_MSG62},
    {WEAPON_ROD_MEIHU,            22,   WEAPON_ROD_MEIHU_TYPE,                  EQUIP_HERO_ROD,         0,     10,       "冥府の杖",                     WEAPON_MSG63},
    {WEAPON_ROD_SEIREI,           26,   WEAPON_ROD_SEIREI_TYPE,                 EQUIP_HERO_ROD,       150,     30,       "精霊の杖",                     WEAPON_MSG64},
    {WEAPON_ROD_KENZYA,           30,   WEAPON_ROD_KENZYA_TYPE,                 EQUIP_HERO_ROD,       220,     70,       "賢者の杖",                     WEAPON_MSG65},
    {WEAPON_ROD_SEIZYO,           36,   WEAPON_ROD_SEIZYO_TYPE,                 EQUIP_HERO_ROD,         0,    100,       "聖女の杖",                     WEAPON_MSG66},
    {WEAPON_ROD_GIONGA,           41,   WEAPON_ROD_GIONGA_TYPE,                 EQUIP_HERO_ROD,         0,    220,       "銀河の杖",                     WEAPON_MSG67},
    {WEAPON_ROD_LAEVATEINN,       50,   WEAPON_ROD_LAEVATEINN_TYPE,             I_SATO,                 0,      0,       "想起・レーヴァテイン",               WEAPON_MSG68},
};



/*
 * ver1. 2021/07/11
 * 防具情報を管理すデータベース
 * -
 * id           防具ID
 * def          物防
 * res          魔防
 * effect_type  効果
 * equip_hero   装備可能キャラ
 * *name        装備名
 */
typedef struct armor_db
{
    uint8_t  id;
    uint8_t  def;
    uint8_t  res;
    uint32_t effect_type;
    uint8_t  equip_hero;
    uint32_t buy;
    uint32_t cell;
    const char *name;
    const char *msg;
} ArmorDB;

static const ArmorDB armor_db[] =
{
    {ARMOR_CLIP_TREE,           3,   3,     ARMOR_CLIP_TREE_TYPE,           EQUIP_HERO_CLIP,      8,     2,     "木のヘアピン"              ,       ARMOR_MSG0},
    {ARMOR_HAT_MORI,            5,   5,     ARMOR_HAT_MORI_TYPE,            EQUIP_HERO_HAT,      14,     4,     "森の帽子"                  ,       ARMOR_MSG1},
    {ARMOR_HAT_GROUND,          7,   5,     ARMOR_HAT_GROUND_TYPE,          EQUIP_HERO_HAT,      22,     7,     "大地の帽子"                  ,     ARMOR_MSG2},
    {ARMOR_RIBBON_COLOR,        5,   7,     ARMOR_RIBBON_COLOR_TYPE,        EQUIP_HERO_RIBBON,    0,    10,     "水色リボン"                ,       ARMOR_MSG3},
    {ARMOR_HAT_FULUT,           8,   7,     ARMOR_HAT_FULUT_TYPE,           EQUIP_HERO_HAT,       0,     8,     "フルーツハット"             ,      ARMOR_MSG4},
    {ARMOR_CRIP_SILBER,        10,  10,     ARMOR_CRIP_SILBER_TYPE,         EQUIP_HERO_CLIP,     25,     8,     "ぎんのかみかざり"            ,     ARMOR_MSG5},
    {ARMOR_HAT_ICE,            13,  10,     ARMOR_HAT_ICE_TYPE,             EQUIP_HERO_HAT,      30,    20,     "氷の帽子"                   ,      ARMOR_MSG6},
    {ARMOR_HAT_HONOO,          16,  12,     ARMOR_HAT_HONOO_TYPE,           EQUIP_HERO_HAT,      50,    20,     "炎の帽子"                   ,      ARMOR_MSG7},
    {ARMOR_HAT_AKAZUKIN,       23,  23,     ARMOR_HAT_AKAZUKIN_TYPE,        EQUIP_HERO_HAT,       0,    15,     "あかずきん"                  ,     ARMOR_MSG8},
    {ARMOR_CLIP_PURATINUM,     24,  22,     ARMOR_CLIP_PURATINUM_TYPE,      EQUIP_HERO_CLIP,     70,    30,     "プラチナのかみかざり"         ,        ARMOR_MSG9},
    {ARMOR_HAT_TENKO,          20,  20,     ARMOR_HAT_TENKO_TYPE,           I_TENK,               0,     0,     "天子の帽子"                  ,     ARMOR_MSG10},
    {ARMOR_RIBBON_USAMIMI,     27,  27,     ARMOR_RIBBON_USAMIMI_TYPE,      EQUIP_HERO_RIBBON,    0,    30,     "うさみみリボン"              ,     ARMOR_MSG11},
    {ARMOR_CRIP_KUMA,          28,  15,     ARMOR_CRIP_KUMA_TYPE,           EQUIP_HERO_CLIP,      0,    25,     "くまさんのヘアピン"           ,        ARMOR_MSG12},
    {ARMOR_HAT_KUROZUKIN,       0,   0,     ARMOR_HAT_KUROZUKIN_TYPE,       EQUIP_HERO_HAT,       0,    25,     "くろずきん"                  ,     ARMOR_MSG13},
    {ARMOR_HAT_VEIL,           34,  30,     ARMOR_HAT_VEIL_TYPE,            EQUIP_HERO_HAT,       0,    10,     "シルクのヴェール"             ,        ARMOR_MSG14},
    {ARMOR_RIBBON_CUTE,        30,  35,     ARMOR_RIBBON_CUTE_TYPE,         EQUIP_HERO_RIBBON,  120,    30,     "キュートなリボン"             ,        ARMOR_MSG15},
    {ARMOR_HAT_CUTE,           35,  30,     ARMOR_HAT_CUTE_TYPE,            EQUIP_HERO_HAT,     120,    30,     "キュートな帽子"               ,        ARMOR_MSG16},
    {ARMOR_CRIP_FLOWER,        38,  30,     ARMOR_CRIP_FLOWER_TYPE,         EQUIP_HERO_CLIP,      0,    40,     "花のコサージュ"               ,        ARMOR_MSG17},
    {ARMOR_CROWN_KOUGYOKU,     42,  38,     ARMOR_CROWN_KOUGYOKU_TYPE,      EQUIP_HERO_CROWN,     0,     0,     "紅玉の冠"                     ,        ARMOR_MSG18},
    {ARMOR_RIBONN_TIRYOKU,     35,  43,     ARMOR_RIBONN_TIRYOKU_TYPE,      EQUIP_HERO_RIBBON,  190,    50,     "知力のリボン"                  ,       ARMOR_MSG19},
    {ARMOR_HAT_TIRYOKU,        40,  40,     ARMOR_HAT_TIRYOKU_TYPE,         EQUIP_HERO_HAT,     190,    50,     "知力の帽子"                   ,        ARMOR_MSG20},
    {ARMOR_HAT_MARISA,         35,  50,     ARMOR_HAT_MARISA_TYPE,          EQUIP_HERO_HAT,       0,     0,     "魔法使いの帽子"                ,       ARMOR_MSG21},
    {ARMOR_RIBBON_REIMU,       35,  50,     ARMOR_RIBBON_REIMU_TYPE,        EQUIP_HERO_RIBBON,    0,     0,     "巫女のリボン"                  ,       ARMOR_MSG22},
    {ARMOR_CROWN_PRINCESS,     45,  40,     ARMOR_CROWN_PRINCESS_TYPE,      EQUIP_HERO_CROWN,     0,     0,     "王女のティアラ"                ,       ARMOR_MSG23},
    {ARMOR_CROWN_GOLD,         50,  40,     ARMOR_CROWN_GOLD_TYPE,          EQUIP_HERO_CROWN,     0,     0,     "黄金のティアラ"                 ,      ARMOR_MSG24},
    {ARMOR_HOUZYOU,            60,  60,     ARMOR_HOUZYOU_TYPE,             I_MINO,               0,     0,     "豊穣神の帽子"                   ,      ARMOR_MSG25},
    {ARMOR_SYSTER,             60,  60,     ARMOR_SYSTER_TYPE,              I_SIZU,               0,     0,     "静葉のリボン"                   ,      ARMOR_MSG26},
    {ARMOR_PONDERING,          60,  60,     ARMOR_PONDERING_TYPE,           I_KANA,               0,     0,     "軍神のねじり鉢巻"                ,     ARMOR_MSG27},
    {ARMOR_HIMAWARIBOUSI,      60,  60,     ARMOR_HIMAWARIBOUSI_TYPE,       I_YUKA,               0,     0,     "太陽の麦わら帽子"                ,     ARMOR_MSG28},
    {ARMOR_HANAKANMURI,        60,  60,     ARMOR_HANAKANMURI_TYPE,         I_KOGA,               0,     0,     "七色の花冠"                      ,     ARMOR_MSG29},
    {ARMOR_KOUMA,              60,  60,     ARMOR_KOUMA_TYPE,               I_REMY,               0,     0,     "紅魔のティアラ"                  ,     ARMOR_MSG30},
    {ARMOR_YATAGARASU,         60,  60,     ARMOR_YATAGARASU_TYPE,          I_SATO,               0,     0,     "ヤタガラスのかみかざり"           ,        ARMOR_MSG31},
    {ARMOR_MOMO,               60,  60,     ARMOR_MOMO_TYPE,                I_TENK,               0,     0,     "天桃のティアラ"                  ,     ARMOR_MSG32},
};


/*
 * ver1. 2021/07/11
 * アクセサリ情報を管理すデータベース
 * -
 * id           アクセサリID
 * effect_type  効果
 * equip_hero   装備可能キャラ
 * *name        装備名
 */
typedef struct amulet_db
{
    uint8_t  id;
    uint32_t effect_type;
    uint8_t  equip_hero;
    uint32_t buy;
    uint32_t cell;
    const char *name;
    const char *msg;
} AmuletDB;

static const AmuletDB amulet_db[] =
{
    {AMULET_RING_1,      AMULET_RING_1_TYPE,     EQUIP_HERO_ALL,   100,   25,    "炎のリング",          AMULET_MSG0},
    {AMULET_RING_2,      AMULET_RING_2_TYPE,     EQUIP_HERO_ALL,   100,   25,    "氷のリング",          AMULET_MSG1},
    {AMULET_RING_3,      AMULET_RING_3_TYPE,     EQUIP_HERO_ALL,   100,   25,    "雷のリング",          AMULET_MSG2},
    {AMULET_RING_4,      AMULET_RING_4_TYPE,     EQUIP_HERO_ALL,   100,   25,    "土のリング",          AMULET_MSG3},
    {AMULET_RING_5,      AMULET_RING_5_TYPE,     EQUIP_HERO_ALL,   100,   25,    "神のリング",          AMULET_MSG4},
    {AMULET_RING_6,      AMULET_RING_6_TYPE,     EQUIP_HERO_ALL,   100,   25,    "霊のリング",          AMULET_MSG5},
    {AMULET_RING_7,      AMULET_RING_7_TYPE,     EQUIP_HERO_ALL,   100,   25,    "アタックリング",        AMULET_MSG6},
    {AMULET_RING_8,      AMULET_RING_8_TYPE,     EQUIP_HERO_ALL,   100,   25,    "シールドリング",        AMULET_MSG7},
    {AMULET_RING_9,      AMULET_RING_9_TYPE,     EQUIP_HERO_ALL,   100,   25,    "マジックリング",        AMULET_MSG8},
    {AMULET_RING_10,     AMULET_RING_10_TYPE,    EQUIP_HERO_ALL,   100,   25,    "スピードリング",        AMULET_MSG9},
    {AMULET_RING_11,     AMULET_RING_11_TYPE,    EQUIP_HERO_ALL,   100,   25,    "レジストリング",        AMULET_MSG10},
    {AMULET_RING_12,     AMULET_RING_12_TYPE,    EQUIP_HERO_ALL,   100,   25,    "コンフィグリング",    AMULET_MSG11},
    {AMULET_RING_13,     AMULET_RING_13_TYPE,    EQUIP_HERO_ALL,   100,   25,    "ポイズンリング",      AMULET_MSG12},
    {AMULET_RING_14,     AMULET_RING_14_TYPE,    EQUIP_HERO_ALL,   100,   25,    "バーサクリング",      AMULET_MSG13},
    {AMULET_RING_15,     AMULET_RING_15_TYPE,    EQUIP_HERO_ALL,   100,   25,    "メヂューサリング",    AMULET_MSG14},
    {AMULET_RING_16,     AMULET_RING_16_TYPE,    EQUIP_HERO_ALL,   100,   25,    "パラライリング",      AMULET_MSG15},
    {AMULET_RING_17,     AMULET_RING_17_TYPE,    EQUIP_HERO_ALL,     0,  100,    "クリスタルリング",    AMULET_MSG16},
    {AMULET_RING_18,     AMULET_RING_18_TYPE,    EQUIP_HERO_ALL,     0,    0,    "ドラゴニックリング",  AMULET_MSG17},
    {AMULET_RING_19,     AMULET_RING_19_TYPE,    EQUIP_HERO_ALL,     0,    0,    "山童の甲羅",         AMULET_MSG18},
    {AMULET_RING_20,     AMULET_RING_20_TYPE,    EQUIP_HERO_ALL,     0,    0,    "魔人経巻の写経",     AMULET_MSG19},
    {AMULET_RING_21,     AMULET_RING_21_TYPE,    EQUIP_HERO_ALL,     0,    0,    "鴉天狗の羽",         AMULET_MSG20},
    {AMULET_RING_22,     AMULET_RING_22_TYPE,    EQUIP_HERO_ALL,     0,    0,    "七曜の護符",         AMULET_MSG21},
    {AMULET_RING_23,     AMULET_RING_23_TYPE,    EQUIP_HERO_ALL,     0,    0,    "閻魔の口紅",         AMULET_MSG22},
    {AMULET_RING_24,     AMULET_RING_24_TYPE,    EQUIP_HERO_ALL,     0,    0,    "銀時計",             AMULET_MSG23},
    {AMULET_RING_25,     AMULET_RING_25_TYPE,    EQUIP_HERO_ALL,     0,    0,    "不死鳥の朧火",        AMULET_MSG24},
    {AMULET_RING_26,     AMULET_RING_26_TYPE,    EQUIP_HERO_ALL,     0,    0,    "ヘンＴ",             AMULET_MSG25},
    {AMULET_RING_27,     AMULET_RING_27_TYPE,    EQUIP_HERO_ALL,     0,    0,    "宝塔",               AMULET_MSG26},
    {AMULET_RING_28,     AMULET_RING_28_TYPE,    EQUIP_HERO_ALL,     0,    0,    "はにわのお守り",      AMULET_MSG27},
    {AMULET_RING_29,     AMULET_RING_29_TYPE,    EQUIP_HERO_ALL,     0,    0,    "マターラマジック",    AMULET_MSG28},
    {AMULET_RING_30,     AMULET_RING_30_TYPE,    EQUIP_HERO_ALL,     0,    0,    "要石のお守り",        AMULET_MSG29},
    {AMULET_RING_31,     AMULET_RING_31_TYPE,    EQUIP_HERO_ALL,     0,    0,    "希望の指輪",          AMULET_MSG30},
    {AMULET_RING_32,     AMULET_RING_32_TYPE,    EQUIP_HERO_ALL,     0,    0,    "七星のネックレス",    AMULET_MSG31},
};


#endif
