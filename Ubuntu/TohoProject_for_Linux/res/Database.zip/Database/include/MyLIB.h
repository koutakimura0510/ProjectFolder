/*
 * Create 2021/07/06
 * Author koutakimura
 * Editor VSCode ver1.57.1
 * -
 * シンボリックファイルのヘッダーをインクルード
 */

#ifndef MyLIB_h   /* prevent circular inclusions */
#define MyLIB_h   /* by using protection macros */

#include <stdio.h>
#include <stdint.h>

// #include <gamemode.h>
#include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/wrapper/game_wrapper.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/wrapper/gamemode.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/wrapper/display_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/minigame/shooting_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/wrapper/event_id_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/database/wrapper/db_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/database/wrapper/db_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/database/wrapper/db_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/draw/detection_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/draw/draw_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/unit/unit_event_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/direct/direct_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/msg/msg_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/battle/battle_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/cmd/cmd_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/system/event/animation/animation_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/RomExternal/id_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/RomExternal/item_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/RomExternal/system_length_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/sound/dtm_macro.h"
// #include "../../../../Xilinx/workspace/Arty_z7_20/HDMI/HDMI_VGA/HDMI_DMA.vitis/RPG_System_ver1/src/hardware/timer/timer_macro.h"


#include "system_msg.h"
#include "item_db.h"
#include "event_msg.h"
#include "minigame.h"

#define FUNC_FILE_SIZE  ((sizeof (func_file))/(sizeof (FuncFile)))

typedef struct
{
	const char *path;
	void (*file_func)(FILE *fp, FILE *byte);
} FuncFile;

#endif
