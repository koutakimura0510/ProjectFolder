#ifndef system_msg_h   /* prevent circular inclusions */
#define system_msg_h   /* by using protection macros */

#define CMD_DB_SIZE 		((sizeof(cmd_db)) / (sizeof(CmdDB)))

/*
 * ver1. 2021/07/03
 * 10進数のデータをsjisエンコードの文字列に変換するための構造体
 */
typedef struct cmd_db
{
	uint32_t id;
	const char *msg;
} CmdDB;

static const CmdDB cmd_db[] = {
	{CMD_MSG_ID_0,			 	"０",		},
	{CMD_MSG_ID_1,			 	"１",		},
	{CMD_MSG_ID_2,			 	"２",		},
	{CMD_MSG_ID_3,			 	"３",		},
	{CMD_MSG_ID_4,			 	"４",		},
	{CMD_MSG_ID_5,			 	"５",		},
	{CMD_MSG_ID_6,			 	"６",		},
	{CMD_MSG_ID_7,			 	"７",		},
	{CMD_MSG_ID_8,			 	"８",		},
	{CMD_MSG_ID_9,			 	"９",		},
	{CMD_MSG_ID_MINORIKO,		"穣子",		},
	{CMD_MSG_ID_SIZUHA,			"静葉",		},
	{CMD_MSG_ID_KANAKO,			"神奈子",	},
	{CMD_MSG_ID_KOGASA,			"小傘",		},
	{CMD_MSG_ID_YUUKA,			"幽香",		},
	{CMD_MSG_ID_REMIRIA,		"レミリア",	},
	{CMD_MSG_ID_SATORI,			"さとり",	},
	{CMD_MSG_ID_TENSI,			"天子",		},
	{CMD_MSG_ID_MAGIC_POWER,	"霊力"		},
	{CMD_MSG_ID_SLASH,			"／"		},
	{CMD_MSG_ID_FIGHT,			"たたかう"	},
	{CMD_MSG_ID_MAGIC,			"わざ"		},
	{CMD_MSG_ID_ITEM,			"アイテム"	},
	{CMD_MSG_ID_CHANGE,			"いれかえ"	},
	{CMD_MSG_ID_TOLK,			"はなす"	},
	{CMD_MSG_ID_ESCAPE,			"にげる"	},
};


#endif