/*
 * Create 2021/07/13
 * Author koutakimura
 * OS     Ubuntu LTS 20.04
 * Editor VSCode ver1.57.1
 * -
 * 構造体のデータをrawファイルに書き出すソースファイル
 * Zynqのソースコードに追記する場合は、main関数の出力ファイル順に構造体を作成すること
 * 
 * デバッグ環境構築
 * F5を押す
 * C++(GDB/LLDB)クリックする //Cの場合でもC++をクリック
 * gcc active ~~~を選択
 * setting.jsonとtasks.jsonができる
 * 
 * Ctrl + Shift + Bでビルド
 * F5でデバッグ
 * F9でブレークポイント
 */

#include "./include/MyLIB.h"


/*
 * ver1. 2021/07/13
 * sjisフォント取得
 */
uint32_t sjis_write(FILE *fp, const char *msg)
{
	uint32_t count = 0;

	while (msg[0] != '\0')
	{
		uint32_t sjis = *msg & 0xff;
		sjis = (sjis << 8) | (*(msg + 1) & 0xff);
		printf("0x%08x\n", sjis);
		msg += 2;
		fprintf(fp, "0x%08x,\n", sjis);
		count++;

		while (*msg == '\n')
		{
			fprintf(fp, "0x%08x,\n", *msg & 0xff);
			printf("0x%x\n", *msg & 0xff);
			msg++;
			count++;
		}
	}

	return count;
}


/*
 * ver1. 2021/07/13
 * アイテムrawファイル書き出し
 */
void item_write(FILE *fp, FILE *byte)
{
	const ItemDB *p = item_db;

	for (uint8_t i = 0; i < ITEM_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(fp, "0x%08x,\n", p->cool_type);
		fprintf(fp, "0x%08x,\n", p->use_type);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->name));
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/13
 * 武器rawファイル書き出し
 */
void weapon_write(FILE *fp, FILE *byte)
{
	const WeaponDB *p = weapon_db;

	for (uint8_t i = 0; i < WEAPON_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(fp, "0x%08x,\n", p->atk);
		fprintf(fp, "0x%08x,\n", p->effect_type);
		fprintf(fp, "0x%08x,\n", p->equip_hero);
		fprintf(fp, "0x%08x,\n", p->buy);
		fprintf(fp, "0x%08x,\n", p->cell);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->name));
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/13
 * 防具rawファイル書き出し
 */
void armor_write(FILE *fp, FILE *byte)
{
	const ArmorDB *p = armor_db;

	for (uint8_t i = 0; i < ARMOR_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(fp, "0x%08x,\n", p->def);
		fprintf(fp, "0x%08x,\n", p->res);
		fprintf(fp, "0x%08x,\n", p->effect_type);
		fprintf(fp, "0x%08x,\n", p->equip_hero);
		fprintf(fp, "0x%08x,\n", p->buy);
		fprintf(fp, "0x%08x,\n", p->cell);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->name));
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/13
 * アクセサリrawファイル書き出し
 */
void amulet_write(FILE *fp, FILE *byte)
{
	const AmuletDB *p = amulet_db;

	for (uint8_t i = 0; i < AMULET_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(fp, "0x%08x,\n", p->effect_type);
		fprintf(fp, "0x%08x,\n", p->equip_hero);
		fprintf(fp, "0x%08x,\n", p->buy);
		fprintf(fp, "0x%08x,\n", p->cell);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->name));
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/15
 * イベントメッセージrawファイル書き出し
 */
void minigame_write(FILE *fp, FILE *byte)
{
	const MinigameDB *p = minigame_db;

	for (uint32_t i = 0; i < MINIGAME_PARA_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(fp, "0x%08x,\n", p->chara_chipid);
		fprintf(fp, "0x%08x,\n", p->move_speed);
		fprintf(fp, "0x%08x,\n", p->jump_rise_speed);
		fprintf(fp, "0x%08x,\n", p->jump_fall_speed);
		fprintf(fp, "0x%08x,\n", p->jump_height);
		fprintf(fp, "0x%08x,\n", p->bomb_number);
		fprintf(fp, "0x%08x,\n", p->bgm_id);
		fprintf(fp, "0x%08x,\n", p->sound_id);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/15
 * イベントメッセージrawファイル書き出し
 */
void event_msg_write(FILE *fp, FILE *byte)
{
	const EventMsg *p = event_msg;

	for (uint32_t i = 0; i < EVENT_MSG_DB_SIZE; i++, p++)
	{
		const char *msg = p->msg;
		fprintf(fp, "0x%08x,\n", p->event_id);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, msg));
	}
}


/*
 * ver1. 2021/07/15
 * イベントメッセージrawファイル書き出し
 */
void cmd_write(FILE *fp, FILE *byte)
{
	const CmdDB *p = cmd_db;

	for (uint32_t i = 0; i < CMD_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->id);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", sjis_write(fp, p->msg));
	}
}


/*
 * ver1. 2021/07/15
 * ミニゲームの得点データ
 */
void score_write(FILE *fp, FILE *byte)
{
	const ScoreDB *p = score_db;

	for (uint32_t i = 0; i < SCORE_DB_SIZE; i++, p++)
	{
		fprintf(fp, "0x%08x,\n", p->time);
		fprintf(fp, "0x%08x,\n", p->score1);
		fprintf(fp, "0x%08x,\n", p->score2);
		fprintf(fp, "0x%08x,\n", p->score3);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
		fprintf(byte, "0x%08x,\n", 1);
	}
}


/*
 * ver1. 2021/07/13
 * バイナリファイル書き出し
 */
int main(int argc, char **argv)
{
	FILE *fp = NULL;
	FILE *byte = NULL;
	byte = fopen("./raw/byte.raw", "wb");

	static const FuncFile func_file[] = {
		{"./raw/item.raw", 		item_write		},
		{"./raw/weapon.raw", 	weapon_write	},
		{"./raw/armor.raw", 	armor_write		},
		{"./raw/amulet.raw", 	amulet_write	},
		{"./raw/event.raw", 	event_msg_write	},
		{"./raw/mini.raw", 		minigame_write	},
		{"./raw/cmd.raw", 		cmd_write		},
		{"./raw/score.raw",		score_write		},
	};
	const FuncFile *p = func_file;

	for (uint32_t i = 0; i < FUNC_FILE_SIZE; i++, p++)
	{
		fp = fopen(p->path, "wb");

		if (fp == NULL)
		{
			printf("open error %s\n", p->path);
			break;
		}
		p->file_func(fp, byte);
		fclose(fp);
	}

	fclose(byte);
	printf("CMD   Msg DB Size = %ld\n", CMD_DB_SIZE);
	printf("Event Msg DB Size = %ld\n", EVENT_MSG_DB_SIZE);
	return 0;
}
